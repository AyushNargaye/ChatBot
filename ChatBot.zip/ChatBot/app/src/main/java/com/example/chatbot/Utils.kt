package com.example.chatbot

import com.google.ai.client.generativeai.BuildConfig

const val ApiKey = com.example.chatbot.BuildConfig.API_KEY
const val Base_Url = "https://aistudio.google.com/app/apikey"